IAM Username:      quanta-ops-reviewer
AWS Access Key ID: AKIAZOXUMXOGZY6JWZPS
AWS Secret Key:    8EsMppYQwqfBDYerdk/HQAztFmlpwb1lzzvBtk2i
AWS Region:        ap-south-1
Amplify URL:       https://<your-branch>.<app-id>.amplifyapp.com
Backend ALB URL:   http://<your-alb-dns>.ap-south-1.elb.amazonaws.com
Test credentials:  testuser / TestPass123!